/**
 * Log Class (Singleton Pattern)
 * -
 * - Author: [Romeo Maunick]
 * - Date: [21/12/2024]
 * - Time: [15:14]
 * - Version: 7.0
 * -
 * Description:
 * The Log class is a singleton used to log events in the depot system.
 * It maintains a record of all log entries, allowing individual events
 * to be logged with a timestamp and optionally writes the log entries
 * to a text file for persistence. This class ensures there is only
 * one instance of the log throughout the application.
 */

import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Log {
    private static Log instance; // Singleton instance of the Log class
    private StringBuilder logEntries; // Stores log entries in memory

    /**
     * Private constructor to prevent instantiation from outside the class.
     * Initializes a StringBuilder to store log entries.
     */
    private Log() {
        logEntries = new StringBuilder();
    }

    /**
     * Retrieves the singleton instance of the Log class.
     * If no instance exists, creates one.
     *
     * @return The single instance of the Log class.
     */
    public static Log getInstance() {
        if (instance == null) {
            instance = new Log();
        }
        return instance;
    }

    /**
     * Logs an event with a timestamp and prints it to the terminal.
     * Additionally, appends the event to the in-memory log and writes it
     * to a specified log file.
     *
     * @param event The event description to be logged.
     */
    public void logEvent(String event) {
        // Create a timestamped entry
        String timestampedEvent = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) + " - " + event;

        // Append to in-memory log
        logEntries.append(timestampedEvent).append("\n");

        // Print the event to the terminal
        System.out.println(timestampedEvent);

        // Write the event to the log file
        writeToLogFile("depot_log7.txt", timestampedEvent);
    }

    /**
     * Writes a single log entry to a log file.
     * Opens the file in append mode to ensure each new event is added to the end.
     *
     * @param filename The name of the file to write to.
     * @param entry    The log entry to be written.
     */
    private void writeToLogFile(String filename, String entry) {
        // Attempt to open the file and write the entry
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
            writer.write(entry); // Write the entry
            writer.newLine();    // Add a newline for separation
        } catch (IOException e) {
            System.err.println("Error writing to log file: " + e.getMessage());
        }
    }

    /**
     * Writes the entire in-memory log history to a specified file.
     * Useful for saving the entire log to a file at once, if needed.
     *
     * @param filename The name of the file to write the full log to.
     */
    public void writeLogToFile(String filename) {
        // Attempt to open the file and write all log entries
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            writer.write(logEntries.toString());
        } catch (IOException e) {
            System.err.println("Error writing log to file: " + e.getMessage());
        }
    }
}



