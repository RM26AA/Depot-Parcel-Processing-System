/**
 * Parcel Class
 * -
 * - Author: [Romeo Maunick]
 * - Date: [21/12/2024]
 * - Time: [15:17]
 * - Version: 7.0
 * -
 * Description:
 * The Parcel class represents a parcel in the depot system. Each parcel has a unique ID,
 * dimensions, weight, the number of days it has been in the depot, and its current status
 * (e.g., "Waiting" or "Collected"). This class provides methods to access and modify parcel
 * details, as well as a method to display parcel information.
 */

public class Parcel {
    // Unique identifier for each parcel
    private String parcelID;

    // Dimensions of the parcel in a string format (e.g., '14 x 10 x 26')
    private String dimensions;

    // Weight of the parcel in kilograms
    private float weight;

    // Number of days the parcel has been in the depot
    private int daysInDepot;

    // Current status of the parcel, e.g., "Collected" or "Waiting"
    private String status;

    /**
     * Constructor to initialize a Parcel object with specific attributes.
     *
     * @param parcelID    Unique identifier for the parcel.
     * @param dimensions  Dimensions of the parcel (e.g., '14 x 10 x 26').
     * @param weight      Weight of the parcel in kilograms.
     * @param daysInDepot Number of days the parcel has been in the depot.
     * @param status      Status of the parcel (e.g., "Waiting" or "Collected").
     */
    public Parcel(String parcelID, String dimensions, float weight, int daysInDepot, String status) {
        this.parcelID = parcelID;
        this.dimensions = dimensions;
        this.weight = weight;
        this.daysInDepot = daysInDepot;
        this.status = status;
    }

    // Getter methods to access private attributes

    /**
     * Gets the parcel ID.
     *
     * @return The unique ID of the parcel.
     */
    public String getParcelID() {
        return parcelID;
    }

    /**
     * Gets the dimensions of the parcel.
     *
     * @return The dimensions of the parcel as a string.
     */
    public String getDimensions() {
        return dimensions;
    }

    /**
     * Gets the weight of the parcel.
     *
     * @return The weight of the parcel in kilograms.
     */
    public float getWeight() {
        return weight;
    }

    /**
     * Gets the number of days the parcel has been in the depot.
     *
     * @return The number of days the parcel has been stored in the depot.
     */
    public int getDaysInDepot() {
        return daysInDepot;
    }

    /**
     * Gets the current status of the parcel.
     *
     * @return The status of the parcel (e.g., "Waiting" or "Collected").
     */
    public String getStatus() {
        return status;
    }

    /**
     * Updates the status of the parcel. Typically used to mark the parcel as "Collected".
     *
     * @param status The new status to set for the parcel.
     */
    public void updateStatus(String status) {
        this.status = status;
    }

    /**
     * Displays parcel details in a formatted manner.
     * This method is primarily for testing and debugging purposes.
     */
    public void displayParcelInfo() {
        System.out.println(this); // Calls the overridden toString method for easy display
    }

    /**
     * Overrides the toString method to provide a formatted string of parcel details.
     *
     * @return A string representation of the parcel's attributes.
     */
    @Override
    public String toString() {
        return "Parcel ID: " + parcelID +
                ",\n Dimensions: " + dimensions +
                ",\n Weight: " + weight + "kg" +
                ",\n Days in Depot: " + daysInDepot +
                ",\n Status: " + status;
    }
}



