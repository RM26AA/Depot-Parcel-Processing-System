/**
 * Manager Class
 * -
 * - Author: [Romeo Maunick]
 * - Date: [21/12/2024]
 * - Time: [15:15]
 * - Version: 7.0
 * -
 * Description:
 * The Manager class serves as the entry point for the Depot Parcel Processing System.
 * It initializes the core components, loads data from CSV files, and sets up the GUI
 * and controller. This class is responsible for setting up the environment needed
 * for the application to run by creating instances of core classes and wiring them together.
 */

public class Manager {
    public static void main(String[] args) {

        // Initialize core components: Queue of customers, parcel map, logging system, and worker
        QueueOfCustomers queue = new QueueOfCustomers();
        ParcelMap parcelMap = new ParcelMap();
        Log log = Log.getInstance(); // Singleton instance for logging events
        Worker worker = new Worker(queue, parcelMap, log); // Worker that processes customers in the queue

        // Load data from CSV files for parcels and customers
        // Loading parcel data from "Parcels.csv"
        parcelMap.readParcelsFromCSV("Parcels.csv");

        // Loading customer data from "cutomers1.csv" (check for correct filename spelling in actual file)
        queue.readCustomersFromCSV("cutomers1.csv");

        // Initialize the GUI for the depot system
        DepotView view = new DepotView();

        // Initialize the controller and connect it to the view, queue, parcel map, and worker
        DepotController controller = new DepotController(view, queue, parcelMap, worker);

        // The GUI is now running, with all components initialized and ready for interaction
    }
}


