/**
 * Customer Class
 * -
 * - Author: [Romeo Maunick]
 * - Date: [21/12/2024]
 * - Time: [15:04]
 * - Version: 7.0
 * -
 * Description:
 * The Customer class represents a customer at the depot. It contains
 * information about the customer, including their unique ID, name,
 * and the ID of the parcel they are supposed to collect.
 * This class provides methods to access customer details and display
 * customer information in a formatted way.
 */
public class Customer {
    // Unique ID assigned to each customer
    private String customerID;

    // Name of the customer
    private String name;

    // ID of the parcel that the customer will collect
    private String parcelID;

    /**
     * Constructor for creating a Customer object.
     *
     * @param customerID Unique ID for the customer
     * @param name       Name of the customer
     * @param parcelID   ID of the parcel to be collected by the customer
     */
    public Customer(String customerID, String name, String parcelID) {
        this.customerID = customerID;
        this.name = name;
        this.parcelID = parcelID;
    }

    /**
     * Getter for customerID.
     *
     * @return the unique ID of the customer
     */
    public String getCustomerID() {
        return customerID;
    }

    /**
     * Getter for name.
     *
     * @return the name of the customer
     */
    public String getName() {
        return name;
    }

    /**
     * Getter for parcelID.
     *
     * @return the ID of the parcel to be collected by the customer
     */
    public String getParcelID() {
        return parcelID;
    }

    /**
     * Displays the customer's information to the console.
     * Prints the customer ID, name, and the parcel ID they are supposed to collect.
     * This method is primarily for testing and debugging purposes.
     */
    public void displayCustomerInfo() {
        System.out.println("Customer ID: " + customerID);
        System.out.println("Name: " + name);
        System.out.println("Parcel ID to Collect: " + parcelID);
        System.out.println();
    }
}

