/**
 * DepotController Class
 * -
 * - Author: [Romeo Maunick]
 * - Date: [21/12/2024]
 * - Time: [15:07]
 * - Version: 7.0
 * -
 * Description:
 * The DepotController class acts as the controller in the MVC architecture,
 * handling the logic between the DepotView (GUI), QueueOfCustomers, ParcelMap,
 * and Worker classes. It listens for user actions, processes them, and updates
 * the view accordingly. This class provides functionality for handling button
 * actions, updating the display, and retrieving formatted information for display.
 */

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DepotController {
    // Dependencies for the controller
    private DepotView view;
    private QueueOfCustomers queue;
    private ParcelMap parcelMap;
    private Worker worker;

    /**
     * Constructor for DepotController.
     * Initializes the controller with the view, queue, parcel map, and worker,
     * and sets up action listeners for handling user actions.
     *
     * @param view       The DepotView instance representing the GUI
     * @param queue      The QueueOfCustomers instance managing customer queue
     * @param parcelMap  The ParcelMap instance managing parcels in the depot
     * @param worker     The Worker instance responsible for processing customers
     */
    public DepotController(DepotView view, QueueOfCustomers queue, ParcelMap parcelMap, Worker worker) {
        this.view = view;
        this.queue = queue;
        this.parcelMap = parcelMap;
        this.worker = worker;

        // Add action listeners to handle button actions in the GUI
        view.getProcessNextButton().addActionListener(new ProcessNextListener());
        view.getRefreshButton().addActionListener(new RefreshListener());

        // Initial display update to show the current state of parcels and queue
        refreshDisplay();
    }

    /**
     * Inner class to handle the "Process Next Customer" button action.
     * When the button is clicked, this listener triggers the worker to
     * process the next customer and refreshes the display to show updated data.
     */
    private class ProcessNextListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            worker.processNextCustomer(); // Process the next customer in the queue
            refreshDisplay(); // Update the display with the new state
        }
    }

    /**
     * Inner class to handle the "Refresh" button action.
     * When the button is clicked, this listener simply refreshes the display
     * to show the current state of parcels and customer queue.
     */
    private class RefreshListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            refreshDisplay(); // Update the display without processing a new customer
        }
    }

    /**
     * Method to refresh the display content in the view.
     * Retrieves the current list of parcels, customer queue, and current parcel
     * being processed, and updates the text areas in the GUI.
     */
    private void refreshDisplay() {
        view.updateParcelList(getParcelList());           // Update parcel list in the view
        view.updateCustomerQueue(getCustomerQueue());     // Update customer queue in the view
        view.updateCurrentParcel(getCurrentParcelInfo()); // Update current parcel info in the view
    }

    /**
     * Helper method to get a formatted string representing the list of all parcels.
     * Iterates through all parcels in the ParcelMap and creates a formatted list.
     *
     * @return A formatted string of parcel IDs and their statuses
     */
    private String getParcelList() {
        StringBuilder sb = new StringBuilder();
        for (Parcel parcel : parcelMap.getAllParcels()) {
            sb.append("ID: ").append(parcel.getParcelID()).append(", ");
            sb.append("Status: ").append(parcel.getStatus()).append("\n");
        }
        return sb.toString();
    }

    /**
     * Helper method to get a formatted string representing the customer queue.
     * Iterates through all customers in the QueueOfCustomers and creates a
     * formatted list of customer names and associated parcel IDs.
     *
     * @return A formatted string of customer names and their parcel IDs
     */
    private String getCustomerQueue() {
        StringBuilder sb = new StringBuilder();
        for (Customer customer : queue.getQueue()) {
            sb.append("Customer: ").append(customer.getName()).append(", ");
            sb.append("Parcel ID: ").append(customer.getParcelID()).append("\n");
        }
        return sb.toString();
    }

    /**
     * Helper method to get information about the current parcel being processed.
     * Retrieves the current parcel information from the Worker class.
     *
     * @return A string indicating the current parcel being processed, or a placeholder
     */
    private String getCurrentParcelInfo() {
        // Retrieve information on the current parcel from the Worker class
        return "Currently Processing: " + worker.getCurrentParcelInfo();
    }
}


