/**
 * Worker Class
 * -
 * - Author: [Romeo Maunick]
 * - Date: [21/12/2024]
 * - Time: [15:23]
 * - Version: 7.0
 * -
 * Description:
 * The Worker class represents a depot worker responsible for processing customers
 * in the queue. The worker retrieves the next customer in line, finds their parcel
 * using the ParcelMap, calculates the collection fee, and updates the parcel's status
 * as "Collected". This class logs each processing event and can provide information
 * on the currently processed parcel.
 */

public class Worker {
    // Queue of customers waiting to be processed
    private QueueOfCustomers customerQueue;

    // Map containing all parcels in the depot, identified by parcel ID
    private ParcelMap parcelMap;

    // Singleton instance of Log class for recording processing events
    private Log log;

    // Tracks the current parcel being processed for display purposes
    private Parcel currentParcel;

    /**
     * Constructor for Worker.
     *
     * @param customerQueue The queue of customers to process.
     * @param parcelMap     The map of parcels in the depot.
     * @param log           The log for recording events.
     */
    public Worker(QueueOfCustomers customerQueue, ParcelMap parcelMap, Log log) {
        this.customerQueue = customerQueue;
        this.parcelMap = parcelMap;
        this.log = log;
    }

    /**
     * Processes the next customer in the queue.
     * Retrieves the customer's parcel, calculates the fee, updates parcel status,
     * and logs the processing details.
     * If no customers are in the queue, logs a message indicating this.
     */
    public void processNextCustomer() {
        // Dequeue the next customer
        Customer customer = customerQueue.dequeue();

        // Check if there are no customers in the queue
        if (customer == null) {
            log.logEvent("No customers in queue to process.");
            currentParcel = null; // No parcel to process
            return;
        }

        // Find the parcel associated with the customer by ID
        currentParcel = parcelMap.findParcelById(customer.getParcelID());

        // If the parcel is not found, log the event and exit
        if (currentParcel == null) {
            String notFoundMessage = "Parcel not found for customer " + customer.getName();
            log.logEvent(notFoundMessage);
            return;
        }

        // Calculate collection fee and update parcel status to "Collected"
        double fee = calculateFee(currentParcel);
        currentParcel.updateStatus("Collected");

        // Log the processing details
        String message = "Processed customer " + customer.getName() + " with Parcel ID: " + currentParcel.getParcelID() +
                ". Collection fee: $" + fee;
        log.logEvent(message);
    }

    /**
     * Retrieves information about the current parcel being processed.
     *
     * @return A string representation of the current parcel's details or a message
     *         indicating no parcel is being processed.
     */
    public String getCurrentParcelInfo() {
        if (currentParcel == null) {
            return "No parcel being processed";
        }
        return currentParcel.toString(); // Returns parcel details using Parcel's toString method
    }

    /**
     * Calculates the collection fee for a parcel based on its weight and
     * days in the depot. The formula used is a sample calculation.
     *
     * @param parcel The parcel for which to calculate the fee.
     * @return The calculated collection fee, rounded to two decimal places.
     */
    private double calculateFee(Parcel parcel) {
        double fee = parcel.getWeight() * 0.5 + parcel.getDaysInDepot() * 0.2;
        return Math.round(fee * 100.0) / 100.0; // Round to two decimal places for readability
    }
}






