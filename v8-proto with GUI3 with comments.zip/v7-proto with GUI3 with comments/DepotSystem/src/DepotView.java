/**
 * DepotView Class
 * -
 * - Author: [Romeo Maunick]
 * - Date: [21/12/2024]
 * - Time: [15:10]
 * - Version: 7.0
 * -
 * Description:
 * The DepotView class is responsible for the graphical user interface (GUI)
 * of the Depot Parcel Processing System. It displays the list of parcels in
 * the depot, the queue of customers, and details of the currently processed
 * parcel. This class also includes buttons for user actions such as processing
 * the next customer, refreshing the view, changing font size and type, and
 * quitting the application.
 * -
 * The class follows the MVC pattern by functioning as the View component.
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DepotView extends JFrame {
    // Panels to display data
    private JTextArea parcelListArea;
    private JTextArea customerQueueArea;
    private JTextArea currentParcelArea;

    // Buttons for actions
    private JButton processNextButton;
    private JButton refreshButton;
    private JButton quitButton;
    private JButton fontSizeButton; // Button for changing font size
    private JButton fontTypeButton; // Button for changing font type

    // Font properties
    private int fontSize = 14;
    private String fontType = "Arial";

    /**
     * Constructor for DepotView.
     * Sets up the main frame and layout, initializes components,
     * and configures the overall appearance of the GUI.
     */
    public DepotView() {
        // Set title and main frame properties
        setTitle("Depot Parcel Processing System");
        setSize(900, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Title Label
        JLabel titleLabel = new JLabel("Depot System", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.BLUE); // Title color
        add(titleLabel, BorderLayout.NORTH);

        // Panel for parcel list with specified background color
        parcelListArea = createTextArea(new Color(240, 248, 255)); // Light blue background
        JPanel parcelPanel = createTitledPanel("Parcels in Depot", parcelListArea);

        // Panel for customer queue with specified background color
        customerQueueArea = createTextArea(new Color(240, 255, 240)); // Light green background
        JPanel queuePanel = createTitledPanel("Customer Queue", customerQueueArea);

        // Panel for current parcel being processed with specified background color
        currentParcelArea = createTextArea(new Color(255, 250, 205)); // Light yellow background
        JPanel currentParcelPanel = createTitledPanel("Current Parcel Being Processed", currentParcelArea);

        // Control panel with action buttons
        processNextButton = new JButton("Process Next Customer");
        refreshButton = new JButton("Refresh");
        quitButton = new JButton("Quit");
        fontSizeButton = new JButton("Change Font Size"); // Button to change font size
        fontTypeButton = new JButton("Change Font Type"); // Button to change font type

        // Set fonts for the buttons
        setButtonFont(processNextButton);
        setButtonFont(refreshButton);
        setButtonFont(quitButton);
        setButtonFont(fontSizeButton);
        setButtonFont(fontTypeButton);

        // Add action listener to quit button to show a confirmation dialog
        quitButton.addActionListener(new QuitButtonListener());

        // Add action listeners for font size and font type buttons
        fontSizeButton.addActionListener(new FontSizeListener());
        fontTypeButton.addActionListener(new FontTypeListener());

        // Arrange buttons in the control panel
        JPanel controlPanel = new JPanel();
        controlPanel.add(processNextButton);
        controlPanel.add(refreshButton);
        controlPanel.add(fontSizeButton);
        controlPanel.add(fontTypeButton);
        controlPanel.add(quitButton);

        // Adding panels to the frame with a grid layout
        JPanel centerPanel = new JPanel(new GridLayout(1, 3, 10, 10)); // Align panels in a row
        centerPanel.add(parcelPanel);
        centerPanel.add(queuePanel);
        centerPanel.add(currentParcelPanel);

        // Adding components to the frame
        add(centerPanel, BorderLayout.CENTER);
        add(controlPanel, BorderLayout.SOUTH);

        // Set background colors for main panels
        centerPanel.setBackground(new Color(230, 230, 250)); // Lavender background
        controlPanel.setBackground(new Color(240, 240, 240)); // Light grey background

        setVisible(true); // Display the frame
    }

    /**
     * Helper method to create a JTextArea with specified background color.
     * Configures font, color, and editability.
     *
     * @param backgroundColor Background color for the JTextArea
     * @return Configured JTextArea instance
     */
    private JTextArea createTextArea(Color backgroundColor) {
        JTextArea textArea = new JTextArea(20, 30);
        textArea.setEditable(false);
        textArea.setFont(new Font(fontType, Font.PLAIN, fontSize)); // Dynamic font size and type
        textArea.setBackground(backgroundColor); // Set background color
        textArea.setForeground(Color.DARK_GRAY); // Set text color
        return textArea;
    }

    /**
     * Helper method to create a JPanel with a centered title and a JTextArea.
     *
     * @param title    The title text for the panel
     * @param textArea The JTextArea to add to the panel
     * @return Configured JPanel instance with title and JTextArea
     */
    private JPanel createTitledPanel(String title, JTextArea textArea) {
        JPanel panel = new JPanel(new BorderLayout());
        JLabel label = new JLabel(title, SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 20)); // Sub-title font
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.add(label, BorderLayout.NORTH);
        panel.add(new JScrollPane(textArea), BorderLayout.CENTER);
        return panel;
    }

    /**
     * Helper method to set font for buttons uniformly.
     *
     * @param button JButton instance whose font needs to be set
     */
    private void setButtonFont(JButton button) {
        button.setFont(new Font("Arial", Font.BOLD, 20));
    }

    /**
     * Inner class to handle the "Quit" button action.
     * Shows a confirmation dialog, and exits the application if "Yes" is selected.
     */
    private class QuitButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Show confirmation dialog
            int choice = JOptionPane.showConfirmDialog(
                    DepotView.this,
                    "Are you sure you want to quit application?",
                    "Confirm Quit",
                    JOptionPane.YES_NO_OPTION);

            // Check user's choice
            if (choice == JOptionPane.YES_OPTION) {
                System.exit(0); // Exit application if 'Yes' is chosen
            }
            // Do nothing if 'No' is chosen; dialog will close
        }
    }

    // Methods to update the text areas

    /**
     * Updates the parcel list display in the GUI.
     *
     * @param parcels Formatted string containing parcel information
     */
    public void updateParcelList(String parcels) {
        parcelListArea.setText(parcels);
    }

    /**
     * Updates the customer queue display in the GUI.
     *
     * @param queue Formatted string containing customer queue information
     */
    public void updateCustomerQueue(String queue) {
        customerQueueArea.setText(queue);
    }

    /**
     * Updates the current parcel display in the GUI.
     *
     * @param parcelInfo String containing information about the current parcel
     */
    public void updateCurrentParcel(String parcelInfo) {
        currentParcelArea.setText(parcelInfo);
    }

    // Getters for buttons to allow the controller to add ActionListeners

    public JButton getProcessNextButton() {
        return processNextButton;
    }

    public JButton getRefreshButton() {
        return refreshButton;
    }

    public JButton getQuitButton() {
        return quitButton;
    }

    /**
     * Inner class to handle font size changes in text areas.
     * Cycles through preset font sizes.
     */
    private class FontSizeListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            fontSize = (fontSize == 14) ? 18 : (fontSize == 18) ? 22 : 14;
            updateTextAreaFonts();
        }
    }

    /**
     * Inner class to handle font type changes in text areas.
     * Cycles through predefined font types (Arial, Calibri, Times New Roman).
     */
    private class FontTypeListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            fontType = switch (fontType) {
                case "Arial" -> "Calibri";
                case "Calibri" -> "Times New Roman";
                case "Times New Roman" -> "Arial";
                default -> "Arial";
            };
            updateTextAreaFonts();
        }
    }

    /**
     * Updates the font size and type for all text areas in the GUI.
     */
    private void updateTextAreaFonts() {
        Font newFont = new Font(fontType, Font.PLAIN, fontSize);
        parcelListArea.setFont(newFont);
        customerQueueArea.setFont(newFont);
        currentParcelArea.setFont(newFont);
    }
}






