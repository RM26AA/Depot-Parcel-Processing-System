/**
 * ParcelMap Class
 * -
 * - Author: [Romeo Maunick]
 * - Date: [21/12/2024]
 * - Time: [15:20]
 * - Version: 7.0
 * -
 * Description:
 * The ParcelMap class manages a collection of Parcel objects in a HashMap,
 * with each Parcel identified by a unique parcel ID. This class provides
 * functionality to add parcels, retrieve all parcels, find a parcel by ID,
 * and load parcel data from a CSV file into the map. Additionally, it includes
 * a method to display all parcels for testing and debugging purposes.
 */

import java.util.HashMap;
import java.util.Map;
import java.util.Collection;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ParcelMap {
    // Map to store Parcel objects, with the parcel ID as the key
    private Map<String, Parcel> parcelMap;

    /**
     * Constructor for ParcelMap.
     * Initializes an empty HashMap to store parcels.
     */
    public ParcelMap() {
        parcelMap = new HashMap<>();
    }

    /**
     * Adds a parcel to the map.
     * Uses the parcel's ID as the key to store it in the map.
     *
     * @param parcel The Parcel object to be added.
     */
    public void addParcel(Parcel parcel) {
        parcelMap.put(parcel.getParcelID(), parcel);
    }

    /**
     * Reads parcel data from a CSV file and adds each parcel to the map.
     * Each line in the CSV file should contain parcel details in the order:
     * parcelID, dimensions, weight, daysInDepot, status.
     *
     * @param filePath The file path of the CSV file.
     */
    public void readParcelsFromCSV(String filePath) {
        String line;
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");

                // Check if line has sufficient data fields
                if (values.length >= 5) {
                    // Remove any non-printable characters from Parcel ID
                    String parcelID = values[0].replaceAll("[^\\x20-\\x7E]", "").trim();
                    String dimensions = values[1].trim();
                    float weight = Float.parseFloat(values[2].trim());
                    int daysInDepot = Integer.parseInt(values[3].trim());
                    String status = values[4].trim();

                    // Create a Parcel object and add it to the map
                    Parcel parcel = new Parcel(parcelID, dimensions, weight, daysInDepot, status);
                    addParcel(parcel);
                }
            }
            System.out.println("Parcels loaded from CSV file.");
        } catch (IOException e) {
            System.err.println("Error reading parcels CSV file: " + e.getMessage());
        }
    }

    /**
     * Finds and retrieves a parcel by its ID.
     *
     * @param parcelID The ID of the parcel to retrieve.
     * @return The Parcel object with the specified ID, or null if not found.
     */
    public Parcel findParcelById(String parcelID) {  // Renamed for clarity
        return parcelMap.get(parcelID);
    }

    /**
     * Gets a collection of all parcels currently in the depot.
     *
     * @return A collection of all Parcel objects in the map.
     */
    public Collection<Parcel> getAllParcels() {
        return parcelMap.values();
    }

    /**
     * Displays all parcels in the depot by calling each parcel's display method.
     * This method is useful for testing and debugging purposes.
     */
    public void displayAllParcels() {
        System.out.println("All Parcels in the Depot:");
        for (Parcel parcel : parcelMap.values()) {
            parcel.displayParcelInfo();
        }
    }
}



