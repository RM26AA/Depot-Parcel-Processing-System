public class Worker {
    private QueueOfCustomers customerQueue;
    private ParcelMap parcelMap;
    private Log log;
    private Parcel currentParcel; // Track the current parcel being processed

    public Worker(QueueOfCustomers customerQueue, ParcelMap parcelMap, Log log) {
        this.customerQueue = customerQueue;
        this.parcelMap = parcelMap;
        this.log = log;
    }

    public void processNextCustomer() {
        Customer customer = customerQueue.dequeue();
        if (customer == null) {
            log.logEvent("No customers in queue to process.");
            currentParcel = null; // No parcel to process
            return;
        }

        currentParcel = parcelMap.findParcelById(customer.getParcelID());
        if (currentParcel == null) {
            String notFoundMessage = "Parcel not found for customer " + customer.getName();
            log.logEvent(notFoundMessage);
            return;
        }

        // Calculate fee and mark the parcel as collected
        double fee = calculateFee(currentParcel);
        currentParcel.updateStatus("Collected"); // Update status to "Collected"

        // Generate a message with processing details
        String message = "Processed customer " + customer.getName() + " with Parcel ID: " + currentParcel.getParcelID() +
                ". Collection fee: $" + fee;

        // Print to terminal and log to file
        log.logEvent(message);
    }

    // New method to retrieve info about the current parcel
    public String getCurrentParcelInfo() {
        if (currentParcel == null) {
            return "No parcel being processed";
        }
        return currentParcel.toString(); // Use toString from Parcel class
    }

    private double calculateFee(Parcel parcel) {
        // Sample calculation based on parcel weight and days in depot
        double fee = parcel.getWeight() * 0.5 + parcel.getDaysInDepot() * 0.2;
        return Math.round(fee * 100.0) / 100.0; // Round to two decimal places
    }
}





