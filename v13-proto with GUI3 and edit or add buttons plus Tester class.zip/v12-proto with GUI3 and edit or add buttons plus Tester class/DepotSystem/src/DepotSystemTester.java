import model.*;

/**
 * DepotSystemTester Class
 * -
 * - Author: Romeo Maunick
 * - Date: [01/01/2025]
 * - Time: [17:35]
 * - Version: 12
 * -
 * Description:
 * This class is used to test the functionality of the Depot System. It validates the behavior
 * of all components including Customer, Parcel, ParcelMap, QueueOfCustomers, Worker, and Log.
 * It simulates the core functionality such as adding, updating, processing, and viewing data.
 */

public class DepotSystemTester {
    public static void main(String[] args) {
        System.out.println("Starting Depot System Tests...\n");

        // Test Customer class
        System.out.println("Testing Customer Class...");
        Customer customer1 = new Customer("C001", "John Doe", "P001");
        Customer customer2 = new Customer("C002", "Jane Smith", "P002");
        customer1.toString();       // Display customer info
        customer1.setName("John Updated"); // Test setName
        customer1.setParcelID("P123");    // Test setParcelID
        System.out.println("Updated Customer: " + customer1.getName() + ", Parcel ID: " + customer1.getParcelID());
        System.out.println("Customer Class Test Passed!\n");

        // Test Parcel class
        System.out.println("Testing Parcel Class...");
        Parcel parcel1 = new Parcel("P001", "10x10x10", 5.5f, 3, "Waiting");
        Parcel parcel2 = new Parcel("P002", "15x10x20", 10.0f, 5, "Collected");
        parcel1.displayParcelInfo();
        parcel1.updateStatus("Collected");
        System.out.println("Updated Parcel Status: " + parcel1.getStatus());
        System.out.println("Parcel Class Test Passed!\n");

        // Test ParcelMap
        System.out.println("Testing ParcelMap Class...");
        ParcelMap parcelMap = new ParcelMap();
        parcelMap.addParcel(parcel1);
        parcelMap.addParcel(parcel2);
        System.out.println("All Parcels in ParcelMap:");
        parcelMap.displayAllParcels();
        System.out.println("Find Parcel by ID 'P001': " + parcelMap.findParcelById("P001"));
        System.out.println("ParcelMap Class Test Passed!\n");

        // Test QueueOfCustomers
        System.out.println("Testing QueueOfCustomers Class...");
        QueueOfCustomers customerQueue = new QueueOfCustomers();
        customerQueue.enqueue(customer1);
        customerQueue.enqueue(customer2);
        System.out.println("Current Queue:");
        customerQueue.displayQueue();
        Customer dequeuedCustomer = customerQueue.dequeue();
        System.out.println("Dequeued Customer: " + dequeuedCustomer.getName());
        System.out.println("Updated Queue:");
        customerQueue.displayQueue();
        System.out.println("QueueOfCustomers Class Test Passed!\n");

        // Test Worker class
        System.out.println("Testing Worker Class...");
        Log log = Log.getInstance(); // Singleton instance
        Worker worker = new Worker(customerQueue, parcelMap, log);

        // Process next customer
        worker.processNextCustomer();
        System.out.println("Current Parcel Being Processed: " + worker.getCurrentParcelInfo());
        worker.processNextCustomer();
        System.out.println("Worker Class Test Passed!\n");

        // Test Log class
        System.out.println("Testing Log Class...");
        log.logEvent("This is a test event.");
        log.writeLogToFile("test_log.txt");
        System.out.println("Log written to 'test_log.txt'");
        System.out.println("Log Class Test Passed!\n");

        // Test Reloading Data
        System.out.println("Simulating Data Reload...");
        ParcelMap reloadParcelMap = new ParcelMap();
        QueueOfCustomers reloadCustomerQueue = new QueueOfCustomers();
        reloadParcelMap.readParcelsFromCSV("Parcels.csv");
        reloadCustomerQueue.readCustomersFromCSV("cutomers1.csv");
        System.out.println("Reloaded Parcels:");
        reloadParcelMap.displayAllParcels();
        System.out.println("Reloaded Customer Queue:");
        reloadCustomerQueue.displayQueue();
        System.out.println("Data Reload Test Passed!\n");

        System.out.println("All Tests Completed Successfully!");
    }
}

