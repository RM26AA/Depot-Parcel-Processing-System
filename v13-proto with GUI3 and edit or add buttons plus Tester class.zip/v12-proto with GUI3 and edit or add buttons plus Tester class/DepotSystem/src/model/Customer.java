package model;

/**
 * Customer Class
 * -
 * - Author: Romeo Maunick
 * - Date: 01/01/2025
 * - Time: 16:58
 * - Version: 12
 * -
 * Description:
 * The Customer class represents a customer at the depot. It contains
 * information about the customer, including their unique ID, name,
 * and the ID of the parcel they are supposed to collect.
 * This class provides methods to access customer details and to display
 * a formatted string representation of the customer's information.
 */
public class Customer {

    // Unique ID assigned to each customer
    private final String customerID;

    // Name of the customer
    private String name;

    // ID of the parcel that the customer will collect
    private String parcelID;

    /**
     * Constructor for creating a Customer object.
     * Ensures that all attributes are properly initialized.
     *
     * @param customerID Unique ID for the customer (non-null).
     * @param name       Name of the customer (non-null).
     * @param parcelID   ID of the parcel to be collected by the customer (non-null).
     */
    public Customer(String customerID, String name, String parcelID) {
        if (customerID == null || name == null || parcelID == null) {
            throw new IllegalArgumentException("Customer attributes cannot be null.");
        }
        this.customerID = customerID.trim();
        this.name = name.trim();
        this.parcelID = parcelID.trim();
    }

    /**
     * Getter for customerID.
     *
     * @return the unique ID of the customer
     */
    public String getCustomerID() {
        return customerID;
    }

    /**
     * Getter for name.
     *
     * @return the name of the customer
     */
    public String getName() {
        return name;
    }

    /**
     * Getter for parcelID.
     *
     * @return the ID of the parcel to be collected by the customer
     */
    public String getParcelID() {
        return parcelID;
    }

    /**
     * Overrides the toString method to provide a formatted
     * string representation of the customer's information.
     *
     * @return A string containing the customer's details.
     */

    /**
     * Setter for name.
     * Allows updating the customer's name.
     *
     * @param name The new name for the customer
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Setter for parcelID.
     * Allows updating the parcel ID associated with the customer.
     *
     * @param parcelID The new parcel ID for the customer
     */
    public void setParcelID(String parcelID) {
        this.parcelID = parcelID;
    }

    @Override
    public String toString() {
        return "Customer ID: " + customerID +
                ", Name: " + name +
                ", Parcel ID: " + parcelID;
    }

}


