package model;

/**
 * Worker Class
 * -
 * - Author: Romeo Maunick
 * - Date: 01/01/2025
 * - Time: 17:11
 * - Version: 12
 * -
 * Description:
 * The Worker class represents a depot worker who is responsible for processing customers
 * in the queue. The worker dequeues the next customer, retrieves their parcel from the ParcelMap,
 * calculates the collection fee, and updates the parcel's status to "Collected".
 * This class also logs all processing events using a Singleton Log instance and
 * provides a method to retrieve information about the currently processed parcel.
 */

public class Worker {
    // Queue holding customers waiting for parcel processing
    private QueueOfCustomers customerQueue;

    // Map holding all parcels in the depot, indexed by parcel ID
    private ParcelMap parcelMap;

    // Singleton instance of Log to record all system events
    private Log log;

    // Tracks the current parcel being processed
    private Parcel currentParcel;

    /**
     * Constructor for Worker.
     * Initializes the worker with dependencies on the customer queue, parcel map, and logging system.
     *
     * @param customerQueue The queue of customers waiting to be processed.
     * @param parcelMap     The map of parcels in the depot.
     * @param log           The Log instance for recording events.
     */
    public Worker(QueueOfCustomers customerQueue, ParcelMap parcelMap, Log log) {
        this.customerQueue = customerQueue;
        this.parcelMap = parcelMap;
        this.log = log;
    }

    /**
     * Processes the next customer in the queue.
     * Retrieves the customer from the queue, finds their associated parcel in the ParcelMap,
     * calculates the collection fee, updates the parcel status, and logs the transaction details.
     *
     * If the queue is empty or the customer's parcel cannot be found, appropriate events are logged.
     */
    public void processNextCustomer() {
        // Retrieve the next customer from the queue
        Customer customer = customerQueue.dequeue();

        // Handle the case where there are no customers in the queue
        if (customer == null) {
            log.logEvent("No customers in queue to process.");
            currentParcel = null; // Reset currentParcel to null
            return;
        }

        // Retrieve the parcel associated with the customer using their parcel ID
        currentParcel = parcelMap.findParcelById(customer.getParcelID());

        // If the parcel is not found, log an error message and exit
        if (currentParcel == null) {
            String notFoundMessage = "Parcel not found for customer " + customer.getName();
            log.logEvent(notFoundMessage);
            return;
        }

        // Calculate the collection fee for the parcel
        double fee = calculateFee(currentParcel);

        // Update the parcel's status to "Collected" after processing
        currentParcel.updateStatus("Collected");

        // Log the details of the processed transaction
        String message = "Processed customer " + customer.getName() +
                " with Parcel ID: " + currentParcel.getParcelID() +
                ". Collection fee: £" + fee;
        log.logEvent(message);
    }

    /**
     * Retrieves information about the current parcel being processed by the worker.
     * If no parcel is being processed, returns an appropriate message.
     *
     * @return A string containing details of the current parcel or a message indicating no parcel is being processed.
     */
    public String getCurrentParcelInfo() {
        if (currentParcel == null) {
            return "No parcel being processed";
        }
        return currentParcel.toString(); // Uses the Parcel class's overridden toString method
    }

    public Log getLog() {
        return log;
    }

    /**
     * Calculates the collection fee for a given parcel.
     * The fee is computed based on the parcel's weight and the number of days it has been in the depot.
     *
     * Formula:
     * Fee = (weight * 0.5) + (daysInDepot * 0.2)
     *
     * @param parcel The Parcel object for which the fee is calculated.
     * @return The calculated collection fee, rounded to two decimal places.
     */
    private double calculateFee(Parcel parcel) {
        double fee = parcel.getWeight() * 0.5 + parcel.getDaysInDepot() * 0.2;
        return Math.round(fee * 100.0) / 100.0; // Round to two decimal places for better readability
    }
}







