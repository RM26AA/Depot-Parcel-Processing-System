public class Manager {
    public static void main(String[] args) {

        // Initialize core components
        QueueOfCustomers queue = new QueueOfCustomers();
        ParcelMap parcelMap = new ParcelMap();
        Log log = Log.getInstance();
        Worker worker = new Worker(queue, parcelMap, log);

        // Load data from CSV files
        parcelMap.readParcelsFromCSV("Parcels.csv");
        queue.readCustomersFromCSV("cutomers1.csv");

        // Initialize the GUI
        DepotView view = new DepotView();
        DepotController controller = new DepotController(view, queue, parcelMap, worker);







    }
}

