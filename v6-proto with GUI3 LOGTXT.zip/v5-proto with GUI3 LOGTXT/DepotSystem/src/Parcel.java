public class Parcel {
    private String parcelID;
    private String dimensions; // e.g., '14 x 10 x 26'
    private float weight;
    private int daysInDepot;
    private String status; // collected or Waiting

    public Parcel(String parcelID, String dimensions, float weight, int daysInDepot, String status) {
        this.parcelID = parcelID;
        this.dimensions = dimensions;
        this.weight = weight;
        this.daysInDepot = daysInDepot;
        this.status = status;
    }

    // Getter methods
    public String getParcelID() {
        return parcelID;
    }

    public String getDimensions() {
        return dimensions;
    }

    public float getWeight() {
        return weight;
    }

    public int getDaysInDepot() {
        return daysInDepot;
    }

    public String getStatus() {
        return status;
    }

    // Method to update status when parcel is collected
    public void updateStatus(String status) {
        this.status = status;
    }

    // Display parcel details
    public void displayParcelInfo() {
        System.out.println(this);
    }

    // Override toString for easy display of parcel details
    @Override
    public String toString() {
        return "Parcel ID: " + parcelID +
                ", Dimensions: " + dimensions +
                ", Weight: " + weight + "kg" +
                ", Days in Depot: " + daysInDepot +
                ", Status: " + status;
    }
}


