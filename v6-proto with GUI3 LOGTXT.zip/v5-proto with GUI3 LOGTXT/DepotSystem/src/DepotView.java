import javax.swing.*;
import java.awt.*;
import java.util.List;

import javax.swing.*;
import java.awt.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DepotView extends JFrame {
    // Panels to display data
    private JTextArea parcelListArea;
    private JTextArea customerQueueArea;
    private JTextArea currentParcelArea;

    // Buttons for actions
    private JButton processNextButton;
    private JButton refreshButton;
    private JButton quitButton;
    private JButton fontSizeButton; // New button for changing font size
    private JButton fontTypeButton; // New button for changing font type

    // Font properties
    private int fontSize = 14;
    private String fontType = "Arial";

    public DepotView() {
        // Set title and main frame properties
        setTitle("Depot Parcel Processing System");
        setSize(900, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Title Label
        JLabel titleLabel = new JLabel("Depot System", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.BLUE); // Title color
        add(titleLabel, BorderLayout.NORTH);

        // Panel for parcel list with larger dimensions, colors, and centered sub-title
        parcelListArea = createTextArea(new Color(240, 248, 255)); // Light blue background for parcels
        JPanel parcelPanel = createTitledPanel("Parcels in Depot", parcelListArea);

        // Panel for customer queue with larger dimensions, colors, and centered sub-title
        customerQueueArea = createTextArea(new Color(240, 255, 240)); // Light green background for customer queue
        JPanel queuePanel = createTitledPanel("Customer Queue", customerQueueArea);

        // Panel for current parcel being processed with color and centered sub-title
        currentParcelArea = createTextArea(new Color(255, 250, 205)); // Light yellow background for current parcel
        JPanel currentParcelPanel = createTitledPanel("Current Parcel Being Processed", currentParcelArea);

        // Control panel with buttons
        processNextButton = new JButton("Process Next Customer");
        refreshButton = new JButton("Refresh");
        quitButton = new JButton("Quit");
        fontSizeButton = new JButton("Change Font Size"); // New Font Size button
        fontTypeButton = new JButton("Change Font Type"); // New Font Type button

        // Set button fonts
        setButtonFont(processNextButton);
        setButtonFont(refreshButton);
        setButtonFont(quitButton);
        setButtonFont(fontSizeButton);
        setButtonFont(fontTypeButton);

        // Add action listener to quit button to exit the application
        quitButton.addActionListener(e -> System.exit(0));

        // Add action listeners for font size and font type buttons
        fontSizeButton.addActionListener(new FontSizeListener());
        fontTypeButton.addActionListener(new FontTypeListener());

        JPanel controlPanel = new JPanel();
        controlPanel.add(processNextButton);
        controlPanel.add(refreshButton);
        controlPanel.add(fontSizeButton);
        controlPanel.add(fontTypeButton);
        controlPanel.add(quitButton);

        // Adding panels to the frame with a grid layout
        JPanel centerPanel = new JPanel(new GridLayout(1, 3, 10, 10)); // Align panels in a row
        centerPanel.add(parcelPanel);
        centerPanel.add(queuePanel);
        centerPanel.add(currentParcelPanel);

        // Adding components to the frame
        add(centerPanel, BorderLayout.CENTER);
        add(controlPanel, BorderLayout.SOUTH);

        // Set background color for the main window
        centerPanel.setBackground(new Color(230, 230, 250)); // Lavender background
        controlPanel.setBackground(new Color(240, 240, 240)); // Light grey background

        setVisible(true);
    }

    // Helper method to create a JTextArea with default styling and background color
    private JTextArea createTextArea(Color backgroundColor) {
        JTextArea textArea = new JTextArea(20, 30);
        textArea.setEditable(false);
        textArea.setFont(new Font(fontType, Font.PLAIN, fontSize)); // Use dynamic font size and type
        textArea.setBackground(backgroundColor); // Set background color
        textArea.setForeground(Color.DARK_GRAY); // Set text color
        return textArea;
    }

    // Helper method to create a panel with a centered title
    private JPanel createTitledPanel(String title, JTextArea textArea) {
        JPanel panel = new JPanel(new BorderLayout());
        JLabel label = new JLabel(title, SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 20)); // Sub-title font
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.add(label, BorderLayout.NORTH);
        panel.add(new JScrollPane(textArea), BorderLayout.CENTER);
        return panel;
    }

    // Helper method to set font for buttons
    private void setButtonFont(JButton button) {
        button.setFont(new Font("Arial", Font.BOLD, 20));
    }

    // Methods to update the text areas
    public void updateParcelList(String parcels) {
        parcelListArea.setText(parcels);
    }

    public void updateCustomerQueue(String queue) {
        customerQueueArea.setText(queue);
    }

    public void updateCurrentParcel(String parcelInfo) {
        currentParcelArea.setText(parcelInfo);
    }

    // Getters for buttons to add ActionListeners
    public JButton getProcessNextButton() {
        return processNextButton;
    }

    public JButton getRefreshButton() {
        return refreshButton;
    }

    public JButton getQuitButton() {
        return quitButton;
    }

    // ActionListener to change font size
    private class FontSizeListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            // Cycle through a few font sizes for simplicity
            fontSize = (fontSize == 14) ? 18 : (fontSize == 18) ? 22 : 14;
            updateTextAreaFonts();
        }
    }

    // ActionListener to change font type
    private class FontTypeListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            // Cycle through a few font types
            fontType = switch (fontType) {
                case "Arial" -> "Calibri";
                case "Calibri" -> "Times New Roman";
                case "Times New Roman" -> "Arial";
                default -> "Arial";
            };
            updateTextAreaFonts();
        }
    }

    // Method to update fonts in all text areas based on current font size and type
    private void updateTextAreaFonts() {
        Font newFont = new Font(fontType, Font.PLAIN, fontSize);
        parcelListArea.setFont(newFont);
        customerQueueArea.setFont(newFont);
        currentParcelArea.setFont(newFont);
    }
}





