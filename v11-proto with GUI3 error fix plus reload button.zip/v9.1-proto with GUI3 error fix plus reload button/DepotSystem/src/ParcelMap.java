/**
 * ParcelMap Class
 * -
 * - Author: Romeo Maunick
 * - Date: 31/12/2024
 * - Time: 17:08
 * - Version: 9.1
 * -
 * Description:
 * The ParcelMap class manages a collection of Parcel objects using a HashMap,
 * where each Parcel is identified by a unique parcel ID. This class provides
 * methods to add parcels, find parcels by their ID, retrieve all parcels, and
 * load parcel data from a CSV file. Additionally, it includes a method to display
 * all parcels for testing and debugging purposes.
 */
import java.util.HashMap;
import java.util.Map;
import java.util.Collection;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ParcelMap {
    // Map to store Parcel objects, keyed by their unique parcel ID
    private Map<String, Parcel> parcelMap;

    /**
     * Constructor for ParcelMap.
     * Initializes an empty HashMap to manage Parcel objects.
     */
    public ParcelMap() {
        parcelMap = new HashMap<>();
    }

    /**
     * Adds a Parcel object to the map.
     * The parcel ID serves as the key for easy retrieval.
     *
     * @param parcel The Parcel object to add to the map.
     */
    public void addParcel(Parcel parcel) {
        parcelMap.put(parcel.getParcelID(), parcel);
    }

    /**
     * Reads parcel data from a CSV file and populates the map.
     * Each line in the CSV file should follow the format:
     * parcelID, dimensions, weight, daysInDepot, status.
     *
     * Example CSV line:
     * X123,14 x 10 x 26,2.5,5,Waiting
     *
     * @param filePath The path to the CSV file containing parcel data.
     */
    public void readParcelsFromCSV(String filePath) {
        String line;
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");

                // Ensure the line contains all required data fields
                if (values.length >= 6) {
                    // Sanitize parcel ID to remove non-printable characters
                    String parcelID = values[0].replaceAll("[^\\x20-\\x7E]", "").trim();
                    String dimensions = values[1].trim() + "x" + values[2].trim() + "x" + values[3].trim();     // New version
                    float weight = Float.parseFloat(values[4].trim());
                    int daysInDepot = Integer.parseInt(values[5].trim());
                    String status = values[6].trim();

                    // Create a Parcel object and add it to the map
                    Parcel parcel = new Parcel(parcelID, dimensions, weight, daysInDepot, status);
                    addParcel(parcel);
                }
            }
            System.out.println("Parcels successfully loaded from CSV file.");
        } catch (IOException e) {
            System.err.println("Error reading parcels CSV file: " + e.getMessage());
        }
    }

    /**
     * Finds a Parcel in the map by its unique parcel ID.
     *
     * @param parcelID The unique ID of the parcel to retrieve.
     * @return The Parcel object with the specified ID, or null if not found.
     */
    public Parcel findParcelById(String parcelID) {
        return parcelMap.get(parcelID);
    }

    /**
     * Retrieves a collection of all Parcel objects stored in the map.
     *
     * @return A collection containing all Parcel objects in the map.
     */
    public Collection<Parcel> getAllParcels() {
        return parcelMap.values();
    }

    /**
     * Displays all Parcel objects currently in the depot.
     * Each parcel's details are printed to the console.
     * This method is intended for testing and debugging purposes.
     */
    public void displayAllParcels() {
        System.out.println("All Parcels in the Depot:");
        for (Parcel parcel : parcelMap.values()) {
            parcel.displayParcelInfo();
        }
    }
}




