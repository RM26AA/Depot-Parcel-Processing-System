package view;
/**
 * DepotView Class
 * -
 * - Author: Romeo Maunick
 * - Date: 31/12/2024
 * - Time: 17:03
 * - Version: 11
 * -
 * Description:
 * The DepotView class is the graphical user interface (GUI) for the Depot Parcel
 * Processing System. It displays the list of parcels in the depot, the queue of customers,
 * and details of the currently processed parcel. This class includes buttons for user actions
 * like processing the next customer, refreshing the display, changing font size and type, and quitting
 * the application.
 * -
 * This class adheres to the MVC design pattern by serving as the View component.
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DepotView extends JFrame {
    // Panels to display data
    private JTextArea parcelListArea;      // Displays list of parcels
    private JTextArea customerQueueArea;  // Displays customer queue
    private JTextArea currentParcelArea;  // Displays current parcel being processed

    // Following fields for new buttons
    private JButton addParcelButton;   // Button to add a new parcel
    private JButton editParcelButton;  // Button to edit a selected parcel
    private JButton addCustomerButton; // Button to add a new customer
    private JButton editCustomerButton; // Button to edit a selected customer

    // Buttons for user interactions
    private JButton reloadDataButton;         // Button to reload data
    private JButton processNextButton; // Button to process next customer
    private JButton refreshButton;     // Button to refresh the display
    private JButton quitButton;        // Button to quit the application
    private JButton fontSizeButton;    // Button to change font size
    private JButton fontTypeButton;    // Button to change font type

    // Font customization properties
    private int fontSize = 14;         // Default font size
    private String fontType = "Arial"; // Default font type

    /**
     * Constructor for DepotView.
     * Sets up the main window layout, initializes components, and configures the GUI.
     */
    public DepotView() {
        // Set main frame properties
        setTitle("Depot Parcel Processing System");
        setSize(900, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Title Label at the top
        JLabel titleLabel = new JLabel("Depot System", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.BLUE); // Title text color
        add(titleLabel, BorderLayout.NORTH);

        // Create and configure the central panels
        parcelListArea = createTextArea(new Color(240, 248, 255)); // Light blue
        JPanel parcelPanel = createTitledPanel("Parcels in Depot", parcelListArea);

        customerQueueArea = createTextArea(new Color(240, 255, 240)); // Light green
        JPanel queuePanel = createTitledPanel("Customer Queue", customerQueueArea);

        currentParcelArea = createTextArea(new Color(255, 250, 205)); // Light yellow
        JPanel currentParcelPanel = createTitledPanel("Current Parcel Being Processed", currentParcelArea);

        // Create the control panel with buttons
        reloadDataButton = new JButton("Reload Data");
        processNextButton = new JButton("Process Next Customer");
        refreshButton = new JButton("Refresh");
        quitButton = new JButton("Quit");
        fontSizeButton = new JButton("Change Font Size");
        fontTypeButton = new JButton("Change Font Type");

        // Apply uniform fonts to buttons
        setButtonFont(reloadDataButton);
        setButtonFont(processNextButton);
        setButtonFont(refreshButton);
        setButtonFont(quitButton);
        setButtonFont(fontSizeButton);
        setButtonFont(fontTypeButton);

        // Add action listeners to buttons
        quitButton.addActionListener(new QuitButtonListener());   // Confirmation dialog on quit
        fontSizeButton.addActionListener(new FontSizeListener()); // Change font size
        fontTypeButton.addActionListener(new FontTypeListener()); // Change font type

        // Arrange buttons in the control panel
        JPanel controlPanel = new JPanel();
        controlPanel.add(reloadDataButton);
        controlPanel.add(processNextButton);
        controlPanel.add(refreshButton);
        controlPanel.add(fontSizeButton);
        controlPanel.add(fontTypeButton);
        controlPanel.add(quitButton);

        // Arrange the display panels in the center
        JPanel centerPanel = new JPanel(new GridLayout(1, 3, 10, 10));
        centerPanel.add(parcelPanel);
        centerPanel.add(queuePanel);
        centerPanel.add(currentParcelPanel);

        // Add panels to the main frame
        add(centerPanel, BorderLayout.CENTER);
        add(controlPanel, BorderLayout.SOUTH);

        // Set background colors
        centerPanel.setBackground(new Color(230, 230, 250)); // Lavender
        controlPanel.setBackground(new Color(240, 240, 240)); // Light grey

        addParcelButton = new JButton("Add Parcel");
        editParcelButton = new JButton("Edit Parcel");
        addCustomerButton = new JButton("Add Customer");
        editCustomerButton = new JButton("Edit Customer");

        // Set button font for consistency
        setButtonFont(addParcelButton);
        setButtonFont(editParcelButton);
        setButtonFont(addCustomerButton);
        setButtonFont(editCustomerButton);

        // Add the buttons to their respective panels
        JPanel parcelControlPanel = new JPanel();
        parcelControlPanel.add(addParcelButton);
        parcelControlPanel.add(editParcelButton);

        JPanel customerControlPanel = new JPanel();
        customerControlPanel.add(addCustomerButton);
        customerControlPanel.add(editCustomerButton);

        // Add the control panels below the respective panels in the layout
        parcelPanel.add(parcelControlPanel, BorderLayout.SOUTH);
        queuePanel.add(customerControlPanel, BorderLayout.SOUTH);

        // Display the frame
        setVisible(true);
    }

    /**
     * Creates a JTextArea with default configurations for display purposes.
     *
     * @param backgroundColor The background color of the JTextArea
     * @return Configured JTextArea instance
     */
    private JTextArea createTextArea(Color backgroundColor) {
        JTextArea textArea = new JTextArea(20, 30);
        textArea.setEditable(false); // Make non-editable
        textArea.setFont(new Font(fontType, Font.PLAIN, fontSize)); // Set initial font
        textArea.setBackground(backgroundColor); // Set background color
        textArea.setForeground(Color.DARK_GRAY); // Set text color
        return textArea;
    }

    /**
     * Creates a JPanel containing a centered title and a scrollable JTextArea.
     *
     * @param title    Title text for the panel
     * @param textArea The JTextArea to include in the panel
     * @return Configured JPanel instance
     */
    private JPanel createTitledPanel(String title, JTextArea textArea) {
        JPanel panel = new JPanel(new BorderLayout());
        JLabel label = new JLabel(title, SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 20)); // Bold font for sub-titles
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.add(label, BorderLayout.NORTH);
        panel.add(new JScrollPane(textArea), BorderLayout.CENTER);
        return panel;
    }

    /**
     * Sets a consistent font style for the action buttons.
     *
     * @param button JButton instance to style
     */
    private void setButtonFont(JButton button) {
        button.setFont(new Font("Arial", Font.BOLD, 20));
    }

    /**
     * Inner class to handle quit button click.
     * Displays a confirmation dialog and exits the application if confirmed.
     */
    private class QuitButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int choice = JOptionPane.showConfirmDialog(
                    DepotView.this,
                    "Are you sure you want to quit the application?",
                    "Confirm Quit",
                    JOptionPane.YES_NO_OPTION);

            if (choice == JOptionPane.YES_OPTION) {
                System.exit(0); // Exit application
            }
        }
    }

    /**
     * Updates the parcel list display.
     *
     * @param parcels Formatted string of parcel details
     */
    public void updateParcelList(String parcels) {
        parcelListArea.setText(parcels);
    }

    /**
     * Updates the customer queue display.
     *
     * @param queue Formatted string of customer queue details
     */
    public void updateCustomerQueue(String queue) {
        customerQueueArea.setText(queue);
    }

    /**
     * Updates the current parcel being processed display.
     *
     * @param parcelInfo Formatted string of current parcel details
     */
    public void updateCurrentParcel(String parcelInfo) {
        currentParcelArea.setText(parcelInfo);
    }

    // Getters for buttons to allow Controller to attach listeners
    public JButton getProcessNextButton() {
        return processNextButton;
    }

    public JButton getRefreshButton() {
        return refreshButton;
    }

    public JButton getQuitButton() {
        return quitButton;
    }

    public JButton getReloadDataButton() {
        return reloadDataButton;
    }

    public JButton getAddParcelButton(){ return addParcelButton;}
    public JButton getEditParcelButton(){ return editParcelButton;}
    public JButton getAddCustomerButton(){ return addCustomerButton;}
    public JButton getEditCustomerButton(){ return editCustomerButton;}

    /**
     * Listener for cycling through font sizes in text areas.
     */
    private class FontSizeListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            fontSize = (fontSize == 14) ? 18 : (fontSize == 18) ? 22 : 14;
            updateTextAreaFonts();
        }
    }

    /**
     * Listener for cycling through font types in text areas.
     */
    private class FontTypeListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            fontType = switch (fontType) {
                case "Arial" -> "Calibri";
                case "Calibri" -> "Times New Roman";
                case "Times New Roman" -> "Arial";
                default -> "Arial";
            };
            updateTextAreaFonts();
        }
    }

    /**
     * Updates the font size and type for all text areas in the GUI.
     */
    private void updateTextAreaFonts() {
        Font newFont = new Font(fontType, Font.PLAIN, fontSize);
        parcelListArea.setFont(newFont);
        customerQueueArea.setFont(newFont);
        currentParcelArea.setFont(newFont);
    }
}







