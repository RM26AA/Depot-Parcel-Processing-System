package model;
/**
 * QueueOfCustomers Class
 * -
 * - Author: Romeo Maunick
 * - Date: 31/12/2024
 * - Time: 17:09
 * - Version: 11
 * -
 * Description:
 * The QueueOfCustomers class manages a queue of Customer objects using a LinkedList.
 * It provides methods for adding (enqueue) and removing (dequeue) customers from the queue,
 * loading customer data from a CSV file, and displaying the current queue status.
 * This class acts as a container for customers waiting to collect their parcels in the depot system.
 */

import java.util.LinkedList;
import java.util.Queue;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class QueueOfCustomers {
    // Queue to store Customer objects in a first-in-first-out (FIFO) order
    private Queue<Customer> customerQueue;

    /**
     * Constructor for QueueOfCustomers.
     * Initializes an empty LinkedList to represent the customer queue.
     */
    public QueueOfCustomers() {
        customerQueue = new LinkedList<>();
    }

    /**
     * Adds a Customer object to the end of the queue.
     *
     * @param customer The Customer object to add to the queue.
     */
    public void enqueue(Customer customer) {
        customerQueue.add(customer);
    }

    /**
     * Reads customer data from a CSV file and populates the queue.
     * Each line in the CSV file should follow the format:
     * customerID, name, parcelID.
     *
     * Example CSV line:
     * C001,John Doe,X123
     *
     * @param filePath The file path of the CSV file containing customer data.
     */
    public void readCustomersFromCSV(String filePath) {
        String line;
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");

                // Ensure the line contains the required data fields
                if (values.length >= 3) {
                    String customerID = values[0].trim();
                    String name = values[1].trim();
                    String parcelID = values[2].trim();

                    // Create a Customer object and add it to the queue
                    Customer customer = new Customer(customerID, name, parcelID);
                    enqueue(customer);
                }
            }
            System.out.println("Customers successfully loaded from CSV file.");
        } catch (IOException e) {
            System.err.println("Error reading customers CSV file: " + e.getMessage());
        }
    }

    /**
     * Removes a Customer object from the front of the queue.
     * Prints a message if the queue is empty.
     *
     * @return The Customer object removed from the queue, or null if the queue is empty.
     */
    public Customer dequeue() {
        Customer customer = customerQueue.poll(); // Removes and returns the head of the queue
        if (customer != null) {
            System.out.println("Customer " + customer.getName() + " removed from the queue.");
        } else {
            System.out.println("Queue is empty.");
        }
        return customer;
    }

    /**
     * Retrieves the current queue of customers.
     *
     * @return The queue of Customer objects as a Queue.
     */
    public Queue<Customer> getQueue() {
        return customerQueue;
    }

    /**
     * Displays the current customer queue.
     * Each customer's name and associated parcel ID are printed to the console.
     * This method is primarily for testing and debugging purposes.
     */
    public void displayQueue() {
        System.out.println("Current Customer Queue:");
        for (Customer customer : customerQueue) {
            System.out.println(" - " + customer.getName() + " (Parcel ID: " + customer.getParcelID() + ")");
        }
    }
}




