import controller.DepotController;
import model.Log;
import model.ParcelMap;
import model.QueueOfCustomers;
import model.Worker;
import view.DepotView;

/**
 * Manager Class
 * -
 * - Author: Romeo Maunick
 * - Date: 31/12/2024
 * - Time: 17:05
 * - Version: 11
 * -
 * Description:
 * The Manager class acts as the entry point for the Depot Parcel Processing System.
 * It initializes the core components, loads data from CSV files, and connects the
 * View (GUI), Controller, and Model components to create a functioning application.
 * This class follows the MVC (Model-View-Controller) design pattern, setting up
 * the necessary dependencies for seamless interaction.
 */

public class Manager {
    public static void main(String[] args) {
        // Step 1: Initialize Core Components
        // - QueueOfCustomers: Manages the customer queue.
        // - ParcelMap: Manages parcels stored in the depot.
        // - Log: Singleton instance to log system events.
        // - Worker: Responsible for processing customers and parcels.
        QueueOfCustomers queue = new QueueOfCustomers();
        ParcelMap parcelMap = new ParcelMap();
        Log log = Log.getInstance(); // Singleton instance for logging
        Worker worker = new Worker(queue, parcelMap, log);

        // Step 2: Load Data from CSV Files
        // Load parcel data into the ParcelMap
        System.out.println("Loading parcel data from 'Parcels.csv'...");
        parcelMap.readParcelsFromCSV("Parcels.csv");

        // Load customer data into the QueueOfCustomers
        System.out.println("Loading customer data from 'cutomers1.csv'...");
        queue.readCustomersFromCSV("cutomers1.csv");

        // Step 3: Initialize the GUI (View)
        // - DepotView: Provides the graphical interface for displaying parcel, customer, and processing information.
        System.out.println("Initializing Depot GUI...");
        DepotView view = new DepotView();

        // Step 4: Set Up the Controller
        // - DepotController: Connects the View, Model (QueueOfCustomers and ParcelMap), and Worker.
        System.out.println("Connecting Controller to the View and Model...");
        DepotController controller = new DepotController(view, queue, parcelMap, worker);

        // Step 5: Application is Running
        // - At this point, the GUI is displayed, and the user can interact with the system.
        System.out.println("Depot Parcel Processing System is now running.");
    }
}



