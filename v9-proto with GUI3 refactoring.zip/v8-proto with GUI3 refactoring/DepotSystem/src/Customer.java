/**
 * Customer Class
 * -
 * - Author: Romeo Maunick
 * - Date: 23/12/2024
 * - Time: 16:58
 * - Version: 8
 * -
 * Description:
 * The Customer class represents a customer at the depot. It contains
 * information about the customer, including their unique ID, name,
 * and the ID of the parcel they are supposed to collect.
 * This class provides methods to access customer details and to display
 * a formatted string representation of the customer's information.
 */
public class Customer {

    // Unique ID assigned to each customer
    private final String customerID;

    // Name of the customer
    private final String name;

    // ID of the parcel that the customer will collect
    private final String parcelID;

    /**
     * Constructor for creating a Customer object.
     * Ensures that all attributes are properly initialized.
     *
     * @param customerID Unique ID for the customer (non-null).
     * @param name       Name of the customer (non-null).
     * @param parcelID   ID of the parcel to be collected by the customer (non-null).
     */
    public Customer(String customerID, String name, String parcelID) {
        if (customerID == null || name == null || parcelID == null) {
            throw new IllegalArgumentException("Customer attributes cannot be null.");
        }
        this.customerID = customerID.trim();
        this.name = name.trim();
        this.parcelID = parcelID.trim();
    }

    /**
     * Getter for customerID.
     *
     * @return the unique ID of the customer
     */
    public String getCustomerID() {
        return customerID;
    }

    /**
     * Getter for name.
     *
     * @return the name of the customer
     */
    public String getName() {
        return name;
    }

    /**
     * Getter for parcelID.
     *
     * @return the ID of the parcel to be collected by the customer
     */
    public String getParcelID() {
        return parcelID;
    }

    /**
     * Overrides the toString method to provide a formatted
     * string representation of the customer's information.
     *
     * @return A string containing the customer's details.
     */
    @Override
    public String toString() {
        return "Customer ID: " + customerID +
                ", Name: " + name +
                ", Parcel ID: " + parcelID;
    }
}


